#include <iostream>

int main(int argc, char* argv[]) {
    std::cout << "Hello from {{PROJECT_NAME}}!" << std::endl;
    return 0;
}

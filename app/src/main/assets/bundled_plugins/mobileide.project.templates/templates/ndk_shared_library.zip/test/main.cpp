#include "{{PROJECT_NAME}}.h"
#include <cstdio>
#include <cstring>
#include <cstdlib>

int main() {
    // Test get_greeting
    const char* greeting = {{PROJECT_NAME}}_get_greeting();
    printf("Greeting: %s
", greeting);

    // Test add
    int result = {{PROJECT_NAME}}_add(3, 4);
    printf("3 + 4 = %d
", result);

    if (result != 7) {
        printf("FAIL: expected 7, got %d
", result);
        return 1;
    }

    printf("All tests passed!
");
    return 0;
}

#ifndef {{PROJECT_NAME_UPPER}}_H
#define {{PROJECT_NAME_UPPER}}_H

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Example exported function.
 * Returns a greeting string.
 */
const char* {{PROJECT_NAME}}_get_greeting(void);

/**
 * Example: add two integers.
 */
int {{PROJECT_NAME}}_add(int a, int b);

#ifdef __cplusplus
}
#endif

#endif // {{PROJECT_NAME_UPPER}}_H

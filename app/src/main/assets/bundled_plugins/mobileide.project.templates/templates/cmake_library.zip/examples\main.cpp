#include "{{PROJECT_NAME}}.h"

int main() {
    {{PROJECT_NAME}}::hello();
    return 0;
}

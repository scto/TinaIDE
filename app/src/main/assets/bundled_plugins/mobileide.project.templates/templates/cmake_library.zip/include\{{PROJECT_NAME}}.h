#ifndef {{PROJECT_NAME_UPPER}}_H
#define {{PROJECT_NAME_UPPER}}_H

namespace {{PROJECT_NAME}} {

void hello();

} // namespace {{PROJECT_NAME}}

#endif // {{PROJECT_NAME_UPPER}}_H

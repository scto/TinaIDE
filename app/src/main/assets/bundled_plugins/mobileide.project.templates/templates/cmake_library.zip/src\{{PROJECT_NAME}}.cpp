#include "{{PROJECT_NAME}}.h"
#include <iostream>

namespace {{PROJECT_NAME}} {

void hello() {
    std::cout << "Hello from {{PROJECT_NAME}} library!" << std::endl;
}

} // namespace {{PROJECT_NAME}}

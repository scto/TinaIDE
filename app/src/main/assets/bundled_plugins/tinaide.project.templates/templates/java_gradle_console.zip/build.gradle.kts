plugins {
    java
    application
}
repositories {
    mavenCentral()
}
application {
    mainClass.set("App")
}
java {
    toolchain {
        languageVersion.set(JavaLanguageVersion.of(17))
    }
}
